import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { initials, spineClass, type Book, type BookStatus } from "@/lib/books";

export function StatusPill({
  status,
  className,
}: {
  status: BookStatus;
  className?: string;
}) {
  const onLoan = status === "borrowed";
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium",
        onLoan ? "bg-borrowed/15 text-borrowed" : "bg-available/15 text-available",
        className,
      )}
    >
      <span
        className={cn("h-1.5 w-1.5 rounded-full", onLoan ? "bg-borrowed" : "bg-available")}
      />
      {onLoan ? "On loan" : "Available"}
    </span>
  );
}

export function Spine({ book, className }: { book: Book; className?: string }) {
  return (
    <div
      aria-hidden
      className={cn(
        "flex h-14 w-10 shrink-0 items-center justify-center rounded-md font-display text-xs font-semibold text-primary-foreground",
        spineClass(book.title),
        className,
      )}
    >
      {initials(book.title)}
    </div>
  );
}

export function BookCard({ book }: { book: Book }) {
  return (
    <Link
      to="/book/$id"
      params={{ id: book.id }}
      className="group flex flex-col rounded-xl border border-border bg-card p-4 transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/45 hover:shadow-[0_14px_30px_-18px_oklch(0.3_0.05_260)]"
    >
      <div className="flex items-start gap-3.5">
        <Spine book={book} />
        <div className="min-w-0 flex-1">
          <h3 className="font-display line-clamp-2 text-[15px] font-semibold leading-snug text-card-foreground">
            {book.title}
          </h3>
          <p className="mt-1 truncate text-sm text-muted-foreground">{book.author}</p>
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between gap-3 border-t border-border pt-3">
        <span className="truncate text-xs tracking-wide text-muted-foreground uppercase">
          {book.category}
          {book.year ? ` · ${book.year}` : ""}
        </span>
        <StatusPill status={book.status} />
      </div>
    </Link>
  );
}
