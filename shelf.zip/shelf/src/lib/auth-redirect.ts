const KEY = "shelf-return-to";

function isSafePath(path: string): boolean {
  return path.startsWith("/") && !path.startsWith("//") && !path.includes("://");
}

/** Remember where a user was heading so social sign-in can bring them back. */
export function rememberReturnTo(path: string): void {
  if (!isSafePath(path)) return;
  try {
    window.sessionStorage.setItem(KEY, path);
  } catch {
    // Private-mode storage failures are not worth blocking sign-in over.
  }
}

export function takeReturnTo(): string | null {
  let value: string | null = null;
  try {
    value = window.sessionStorage.getItem(KEY);
    if (value) window.sessionStorage.removeItem(KEY);
  } catch {
    return null;
  }
  return value && isSafePath(value) ? value : null;
}
