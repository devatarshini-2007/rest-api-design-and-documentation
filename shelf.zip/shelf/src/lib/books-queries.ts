import { queryOptions } from "@tanstack/react-query";
import { listBooks } from "./books.functions";
import type { Book } from "./books";

export const booksQueryOptions = queryOptions({
  queryKey: ["books"],
  queryFn: (): Promise<Book[]> => listBooks(),
});
