import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Plus, Search, SlidersHorizontal, X } from "lucide-react";
import { toast } from "sonner";

import { BookCard } from "@/components/book-card";
import { BookFormDialog } from "@/components/book-form-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/hooks/use-auth";
import { booksQueryOptions } from "@/lib/books-queries";
import { rememberReturnTo } from "@/lib/auth-redirect";
import { selectBooks, type Book, type CatalogueFilters } from "@/lib/books";

const SORTS = [
  { value: "recent", label: "Recently added" },
  { value: "title", label: "Title A–Z" },
  { value: "author", label: "Author A–Z" },
  { value: "year", label: "Newest published" },
];

const STATUSES = [
  { value: "all", label: "All" },
  { value: "available", label: "Available" },
  { value: "borrowed", label: "On loan" },
];

type CatalogueSearch = Partial<CatalogueFilters>;

function validateSearch(search: Record<string, unknown>): CatalogueSearch {
  const rawStatus = search["status"];
  const status = rawStatus === "available" || rawStatus === "borrowed" ? rawStatus : "all";

  const rawSort = search["sort"];
  const sort =
    rawSort === "title" || rawSort === "author" || rawSort === "year" || rawSort === "recent"
      ? rawSort
      : "recent";

  const rawQ = search["q"];
  const rawCategory = search["category"];

  return {
    q: typeof rawQ === "string" ? rawQ : "",
    category: typeof rawCategory === "string" ? rawCategory : "all",
    status,
    sort,
  };
}

export const Route = createFileRoute("/")({
  validateSearch,
  loader: ({ context }) => context.queryClient.ensureQueryData(booksQueryOptions),
  head: () => ({
    meta: [
      { title: "Shelf — Community Library Catalogue" },
      {
        name: "description",
        content:
          "Search every title on the shelf, filter by category and availability, and add your own books.",
      },
      { property: "og:title", content: "Shelf — Community Library Catalogue" },
      {
        property: "og:description",
        content:
          "A shared shelf: search the catalogue, see what's on loan, and add the book you just finished.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Catalogue,
});

function Catalogue() {
  const { data: books } = useSuspenseQuery(booksQueryOptions);
  const search = Route.useSearch();
  const filters = useMemo<CatalogueFilters>(
    () => ({
      q: search.q ?? "",
      category: search.category ?? "all",
      status: search.status ?? "all",
      sort: search.sort ?? "recent",
    }),
    [search.q, search.category, search.status, search.sort],
  );
  const navigate = useNavigate();
  const { isSignedIn } = useAuth();

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Book | null>(null);

  const visible = useMemo(() => selectBooks(books, filters), [books, filters]);
  const categories = useMemo(
    () => Array.from(new Set(books.map((book) => book.category))).sort((a, b) => a.localeCompare(b)),
    [books],
  );

  const available = books.filter((book) => book.status === "available").length;
  const onLoan = books.length - available;

  const update = (patch: Partial<CatalogueFilters>) =>
    navigate({
      to: "/",
      search: { ...filters, ...patch },
      replace: true,
    });

  const filtersActive =
    filters.q !== "" || filters.category !== "all" || filters.status !== "all";

  function startAdd() {
    if (!isSignedIn) {
      rememberReturnTo("/");
      toast("Sign in to add a book to the shelf.");
      navigate({ to: "/auth", search: { redirect: "/", mode: "signin" } });
      return;
    }
    setEditing(null);
    setFormOpen(true);
  }

  function startEdit(book: Book) {
    if (!isSignedIn) {
      rememberReturnTo(`/book/${book.id}`);
      navigate({ to: "/auth", search: { redirect: `/book/${book.id}`, mode: "signin" } });
      return;
    }
    setEditing(book);
    setFormOpen(true);
  }

  return (
    <>
      <section className="border-b border-border bg-surface">
        <div className="mx-auto w-full max-w-6xl px-5 py-12 sm:py-16">
          <p className="text-xs font-semibold tracking-[0.22em] text-primary uppercase">
            Community library
          </p>
          <h1 className="font-display mt-4 max-w-2xl text-4xl leading-[1.08] font-semibold text-foreground sm:text-5xl">
            Every title on the shelf, in one place.
          </h1>
          <p className="mt-4 max-w-xl text-base text-muted-foreground">
            Search the catalogue, see what's out on loan, and add the book you just finished
            reading.
          </p>

          <dl className="mt-8 flex flex-wrap gap-x-10 gap-y-4">
            <div>
              <dt className="text-xs tracking-wide text-muted-foreground uppercase">Titles</dt>
              <dd className="font-display mt-1 text-2xl font-semibold text-foreground">
                {books.length}
              </dd>
            </div>
            <div>
              <dt className="text-xs tracking-wide text-muted-foreground uppercase">Available</dt>
              <dd className="font-display mt-1 text-2xl font-semibold text-available">
                {available}
              </dd>
            </div>
            <div>
              <dt className="text-xs tracking-wide text-muted-foreground uppercase">On loan</dt>
              <dd className="font-display mt-1 text-2xl font-semibold text-borrowed">{onLoan}</dd>
            </div>
            <div>
              <dt className="text-xs tracking-wide text-muted-foreground uppercase">Categories</dt>
              <dd className="font-display mt-1 text-2xl font-semibold text-foreground">
                {categories.length}
              </dd>
            </div>
          </dl>
        </div>
      </section>

      <section className="mx-auto w-full max-w-6xl px-5 py-10">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="relative w-full lg:max-w-sm">
            <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={filters.q}
              onChange={(event) => update({ q: event.target.value })}
              placeholder="Search title, author or ISBN"
              className="pl-9"
              aria-label="Search the catalogue"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center rounded-lg border border-border bg-card p-0.5">
              {STATUSES.map((status) => (
                <button
                  key={status.value}
                  type="button"
                  onClick={() => update({ status: status.value })}
                  className={
                    filters.status === status.value
                      ? "rounded-[7px] bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground"
                      : "rounded-[7px] px-3 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
                  }
                >
                  {status.label}
                </button>
              ))}
            </div>

            <Select value={filters.category} onValueChange={(value) => update({ category: value })}>
              <SelectTrigger className="w-[170px] bg-card" aria-label="Filter by category">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All categories</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.sort} onValueChange={(value) => update({ sort: value })}>
              <SelectTrigger className="w-[170px] bg-card" aria-label="Sort the catalogue">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SORTS.map((sort) => (
                  <SelectItem key={sort.value} value={sort.value}>
                    {sort.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button onClick={startAdd}>
              <Plus className="h-4 w-4" />
              Add a book
            </Button>
          </div>
        </div>

        <div className="mt-6 flex items-center justify-between gap-3 text-sm text-muted-foreground">
          <p className="inline-flex items-center gap-2">
            <SlidersHorizontal className="h-3.5 w-3.5" />
            Showing {visible.length} of {books.length}
            {filters.category !== "all" ? ` in ${filters.category}` : ""}
          </p>
          {filtersActive && (
            <button
              type="button"
              onClick={() => navigate({ to: "/", search: { ...filters, q: "", category: "all", status: "all" }, replace: true })}
              className="inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline"
            >
              <X className="h-3 w-3" />
              Clear filters
            </button>
          )}
        </div>

        {visible.length > 0 ? (
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {visible.map((book) => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        ) : books.length === 0 ? (
          <div className="mt-10 rounded-xl border border-dashed border-border bg-card p-10 text-center">
            <h2 className="font-display text-lg font-semibold text-foreground">The shelf is empty</h2>
            <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
              Add the first book and the catalogue will start filling up.
            </p>
            <Button className="mt-5" onClick={startAdd}>
              <Plus className="h-4 w-4" />
              Add the first book
            </Button>
          </div>
        ) : (
          <div className="mt-10 rounded-xl border border-dashed border-border bg-card p-10 text-center">
            <h2 className="font-display text-lg font-semibold text-foreground">No matches</h2>
            <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
              Nothing on the shelf fits those filters yet. Try a wider search.
            </p>
            <Button
              className="mt-5"
              variant="outline"
              onClick={() =>
                navigate({
                  to: "/",
                  search: { ...filters, q: "", category: "all", status: "all" },
                  replace: true,
                })
              }
            >
              Clear filters
            </Button>
          </div>
        )}
      </section>

      <BookFormDialog open={formOpen} onOpenChange={setFormOpen} book={editing} />
    </>
  );
}
