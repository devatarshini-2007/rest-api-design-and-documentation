import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, KeyRound, Library } from "lucide-react";
import { toast } from "sonner";
import "@lovable.dev/cloud-auth-js/styles.css";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";
import { rememberReturnTo } from "@/lib/auth-redirect";
import { lovable } from "@/integrations/lovable/index";
import { supabase } from "@/integrations/supabase/client";
import { cleanText } from "@/lib/books";

type Mode = "signin" | "signup";

type AuthSearch = { redirect?: string; mode?: Mode };

function validateSearch(search: Record<string, unknown>): AuthSearch {
  const rawRedirect = search["redirect"];
  const raw = typeof rawRedirect === "string" ? rawRedirect : "/";
  const redirect = raw.startsWith("/") && !raw.startsWith("//") ? raw : "/";
  const mode: Mode = search["mode"] === "signup" ? "signup" : "signin";
  return { redirect, mode };
}

export const Route = createFileRoute("/auth")({
  validateSearch,
  head: () => ({
    meta: [
      { title: "Sign in — Shelf" },
      {
        name: "description",
        content: "Sign in to Shelf to add, edit and lend books in the community library catalogue.",
      },
      { property: "og:title", content: "Sign in — Shelf" },
      {
        property: "og:description",
        content: "Sign in to Shelf to add, edit and lend books in the community library catalogue.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { redirect: rawRedirect, mode: rawMode } = Route.useSearch();
  const redirect = rawRedirect ?? "/";
  const mode: Mode = rawMode ?? "signin";
  const navigate = useNavigate();
  const { isSignedIn, loading } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirmSent, setConfirmSent] = useState(false);

  useEffect(() => {
    if (!loading && isSignedIn) navigate({ to: redirect as never, replace: true });
  }, [loading, isSignedIn, navigate, redirect]);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    const cleanEmail = cleanText(email);
    if (!cleanEmail) {
      toast.error("Enter your email address.");
      return;
    }
    if (password.length < 6) {
      toast.error("Passwords need at least 6 characters.");
      return;
    }

    setBusy(true);
    try {
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email: cleanEmail,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        if (!data.session) {
          setConfirmSent(true);
          return;
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email: cleanEmail,
          password,
        });
        if (error) throw error;
      }
      navigate({ to: redirect as never, replace: true });
    } catch (error) {
      toast.error(mode === "signup" ? "Couldn't create that account" : "Couldn't sign you in", {
        description: error instanceof Error ? error.message : String(error),
      });
    } finally {
      setBusy(false);
    }
  }

  async function forgotPassword() {
    const cleanEmail = cleanText(email);
    if (!cleanEmail) {
      toast.error("Enter your email above first, then press the link again.");
      return;
    }
    const { error } = await supabase.auth.resetPasswordForEmail(cleanEmail, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) {
      toast.error("Couldn't send that link", { description: error.message });
      return;
    }
    toast.success("Check your email", {
      description: "We sent a link to choose a new password.",
    });
  }

  async function socialSignIn(provider: "google" | "lovable") {
    setBusy(true);
    rememberReturnTo(redirect);
    const result = await lovable.auth.signInWithOAuth(provider, {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      toast.error("Couldn't start sign-in", { description: result.error.message });
      setBusy(false);
      return;
    }
    if (result.redirected) return;
    navigate({ to: redirect as never, replace: true });
  }

  if (confirmSent) {
    return (
      <div className="mx-auto w-full max-w-md px-5 py-20">
        <div className="rounded-2xl border border-border bg-card p-8 text-center">
          <span className="mx-auto flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <KeyRound className="h-5 w-5" />
          </span>
          <h1 className="font-display mt-4 text-xl font-semibold text-foreground">
            Confirm your email
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            We sent a confirmation link to <span className="font-medium text-foreground">{cleanText(email)}</span>.
            Open it to finish creating your account.
          </p>
          <Button className="mt-6" variant="outline" onClick={() => setConfirmSent(false)}>
            Back
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto grid w-full max-w-5xl gap-10 px-5 py-12 lg:grid-cols-2 lg:items-center lg:py-20">
      <div className="hidden lg:block">
        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
          <Library className="h-5 w-5" />
        </span>
        <h2 className="font-display mt-6 text-3xl leading-tight font-semibold text-foreground">
          A shared shelf needs a name on it.
        </h2>
        <p className="mt-4 max-w-md text-muted-foreground">
          Anyone can browse the catalogue. Signing in lets you add a title, mark one on loan, and
          keep the shelf tidy for the next reader.
        </p>
        <ul className="mt-6 space-y-2 text-sm text-muted-foreground">
          <li>Add and edit book records with ISBN and year checks.</li>
          <li>Track which titles are out on loan.</li>
          <li>Remove books you added yourself.</li>
        </ul>
      </div>

      <div className="rounded-2xl border border-border bg-card p-6 sm:p-8">
        <div className="flex items-center rounded-lg border border-border bg-secondary/60 p-0.5">
          {(["signin", "signup"] as const).map((value) => (
            <button
              key={value}
              type="button"
              onClick={() =>
                navigate({
                  to: "/auth",
                  search: { redirect, mode: value },
                  replace: true,
                })
              }
              className={
                mode === value
                  ? "flex-1 rounded-[7px] bg-card px-3 py-2 text-sm font-medium text-foreground shadow-sm"
                  : "flex-1 rounded-[7px] px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
              }
            >
              {value === "signin" ? "Sign in" : "Create account"}
            </button>
          ))}
        </div>

        <form onSubmit={submit} className="mt-6 space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="you@example.com"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label htmlFor="password">Password</Label>
              {mode === "signin" && (
                <button
                  type="button"
                  onClick={() => void forgotPassword()}
                  className="text-xs font-medium text-primary hover:underline"
                >
                  Forgot password?
                </button>
              )}
            </div>
            <Input
              id="password"
              type="password"
              autoComplete={mode === "signup" ? "new-password" : "current-password"}
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="At least 6 characters"
            />
          </div>

          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? "Working…" : mode === "signup" ? "Create account" : "Sign in"}
          </Button>
        </form>

        <div className="my-6 flex items-center gap-3">
          <Separator className="flex-1" />
          <span className="text-xs tracking-wide text-muted-foreground uppercase">or</span>
          <Separator className="flex-1" />
        </div>

        <div className="space-y-2.5">
          <Button variant="outline" className="w-full" onClick={() => void socialSignIn("google")} disabled={busy}>
            Continue with Google
          </Button>
          <button
            type="button"
            className="lovable-auth-button w-full"
            onClick={() => void socialSignIn("lovable")}
            disabled={busy}
          >
            Continue with Lovable
          </button>
        </div>

        <p className="mt-6 text-center">
          <button
            type="button"
            onClick={() => navigate({ to: "/" })}
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Keep browsing without an account
          </button>
        </p>
      </div>
    </div>
  );
}
