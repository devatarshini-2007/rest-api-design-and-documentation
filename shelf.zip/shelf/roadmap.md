# Roadmap

- [x] Enable Lovable Cloud
- [x] Create `books` table with RLS + seed catalogue
- [x] Turn on email/password sign-in; add Google and Lovable sign-in
- [ ] Design tokens: clean, modern, distinctive (src/styles.css)
- [ ] Shared shell in `__root.tsx`: header, footer, toaster, auth listener, fonts
- [ ] Catalogue home: search, category + availability filters, sort, grid
- [ ] Add / edit book dialog with validation (trim, ISBN cleanup, year range)
- [ ] Book detail page `/book/$id`
- [ ] Sign-in / sign-up page `/auth`
- [ ] Test validation rules (vitest)
- [ ] Verify in browser: browse, search, add a book, sign in
- [ ] Save the project to the user's desktop (deliver a downloadable copy in Files)

