CREATE TABLE public.books (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  author text NOT NULL,
  isbn text,
  year integer,
  category text NOT NULL DEFAULT 'General',
  status text NOT NULL DEFAULT 'available',
  notes text,
  added_by uuid DEFAULT auth.uid(),
  added_by_email text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT books_status_check CHECK (status IN ('available', 'borrowed')),
  CONSTRAINT books_year_check CHECK (year IS NULL OR (year >= 1000 AND year <= 2100))
);

GRANT SELECT ON public.books TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.books TO authenticated;
GRANT ALL ON public.books TO service_role;

ALTER TABLE public.books ENABLE ROW LEVEL SECURITY;

CREATE POLICY "books_are_readable_by_anyone"
  ON public.books FOR SELECT
  USING (true);

CREATE POLICY "members_can_add_books"
  ON public.books FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = added_by);

CREATE POLICY "members_can_update_books"
  ON public.books FOR UPDATE TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "members_can_remove_own_books"
  ON public.books FOR DELETE TO authenticated
  USING (auth.uid() = added_by);

CREATE OR REPLACE FUNCTION public.touch_books_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER books_touch_updated_at
  BEFORE UPDATE ON public.books
  FOR EACH ROW
  EXECUTE FUNCTION public.touch_books_updated_at();

INSERT INTO public.books (title, author, isbn, year, category, status, notes) VALUES
  ('The Left Hand of Darkness', 'Ursula K. Le Guin', '9780441478125', 1969, 'Science Fiction', 'available', 'A envoy on an ice-bound world where gender is fluid.'),
  ('The Emperor of All Maladies', 'Siddhartha Mukherjee', '9781439170915', 2010, 'Science', 'borrowed', 'A biography of cancer, beautifully written.'),
  ('Sapiens', 'Yuval Noah Harari', '9780062316097', 2011, 'History', 'available', 'How a forgettable ape ran the planet.'),
  ('The Design of Everyday Things', 'Don Norman', '9780465050658', 2013, 'Design', 'available', 'Affordances, signifiers, and doors that push.'),
  ('Beloved', 'Toni Morrison', '9781400033416', 1987, 'Fiction', 'available', 'Haunting, and worth the reread.'),
  ('Thinking, Fast and Slow', 'Daniel Kahneman', '9780374533557', 2011, 'Psychology', 'borrowed', 'System 1 and System 2.'),
  ('The Overstory', 'Richard Powers', '9780393666856', 2018, 'Fiction', 'available', 'Nine lives, one forest.'),
  ('Braiding Sweetgrass', 'Robin Wall Kimmerer', '9781571313560', 2013, 'Nature', 'available', 'Indigenous wisdom and plant science.'),
  ('Piranesi', 'Susanna Clarke', '9781635575637', 2020, 'Fiction', 'available', 'An endless house of statues and tides.'),
  ('Crying in H Mart', 'Michelle Zauner', '9780525657715', 2021, 'Memoir', 'available', 'Grief, food, and a supermarket in Queens.');